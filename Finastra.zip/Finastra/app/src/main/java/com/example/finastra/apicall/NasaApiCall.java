package com.example.finastra.apicall;

public interface NasaApiCall {

    @Headers("Content-Type: application/json")
    @GET("schedule.json")
    Call<ScheduleApiResponse> getScheduleJson();
}